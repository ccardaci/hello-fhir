# luxottica-eyewear-ig#0.1.0: null(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Eyewear Frame Styles](CodeSystem-frame-styles.md)

### ValueSets

* [Eyewear Frame Styles ValueSet](ValueSet-frame-styles-vs.md)

### Resource Profiles

* [MyPatient](StructureDefinition-MyPatient.md)

### ImplementationGuides

* [Luxottica](ImplementationGuide-luxottica-eyewear-ig.md)

### Examples

* [PatientExample (Patient)](Patient-PatientExample.md)
